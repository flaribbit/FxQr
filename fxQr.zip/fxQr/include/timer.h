/*****************************************************************/
/*                                                               */
/*   CASIO fx-9860G SDK Library                                  */
/*                                                               */
/*   File name : timer.h                                         */
/*                                                               */
/*   Copyright (c) 2006 CASIO COMPUTER CO., LTD.                 */
/*                                                               */
/*****************************************************************/
#ifndef __TIMER_H__
#define __TIMER_H__


// Defines

#define ID_USER_TIMER1          1
#define ID_USER_TIMER2          2
#define ID_USER_TIMER3          3
#define ID_USER_TIMER4          4
#define ID_USER_TIMER5          5


#endif
